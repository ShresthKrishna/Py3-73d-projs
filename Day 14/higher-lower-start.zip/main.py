import random
from replit import clear
from game_data import data
from art import logo, vs

def check(opt_a,opt_b):
  if opt_a>=opt_b :
    return True
  else:
    return False
correct=True
a=random.choice(data)
b=random.choice(data)
score=0
while correct:
  print(f"Compare A: {a['name']}, {a['description']}, from {a['country']}\n\n\n")
  
  print(f"{vs}\n\n\n")

  print(f"Against B: {b['name']}, {b['description']}, from {b['country']}\n\n\n")
  choice=input("Which has more Instagram Followers? 'A' or 'B': ").upper()
  if choice=='A':
    result= check(a["follower_count"],b["follower_count"])
  else:
    result=check(a["follower_count"],b["follower_count"])
  if result:
    clear()
    score+=1
    print(f"Your current score is:{score}")
    a=b
    b=random.choice(data)
    
  elif not result:
    print(f"Your Final score is:{score}")
    correct=False

