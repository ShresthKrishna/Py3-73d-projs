from replit import clear
from art import logo
#HINT: You can call clear() to clear the output in the console.
print(logo)
bid={}
ans="yes"
while ans=="yes":
    name=input("Enter a name: ")
    bid[name]=int(input("Enter your bid: $"))
    ans=input("Are there any other bidders?").lower()
    clear()
max=0
name=''
for i in bid:
  if max< bid[i]:
    max= bid[i]
    name=i


print(f"The highest bidder is {i} with a bidding of ${max}")
